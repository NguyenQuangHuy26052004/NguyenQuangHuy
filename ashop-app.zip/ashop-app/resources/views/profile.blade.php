@extends('layouts.master')

@section('content')

    <h1>This is a Profile</h1>

@endsection
