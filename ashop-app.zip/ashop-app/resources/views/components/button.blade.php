<div>
    <!-- Waste no more time arguing what a good man should be, be one. - Marcus Aurelius -->
    <button>
        {{ $slot }}
        {{ $slot }}
    </button>
</div>
